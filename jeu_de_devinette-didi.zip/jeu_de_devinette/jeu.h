#ifndef JEU_H_INCLUDED
#define JEU_H_INCLUDED

void jeuDeDevinette(int max, int tentativesMax, const char* pseudo); // D�claration avec 3 param�tres

#endif //�JEU_H_INCLUDED
