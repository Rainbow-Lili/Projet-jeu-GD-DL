#ifndef RANDOM_H_INCLUDED
#define RANDOM_H_INCLUDED

int genererNombreAleatoire(int max);

#endif // RANDOM_H_INCLUDED
