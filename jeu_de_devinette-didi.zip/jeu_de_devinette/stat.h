#ifndef STAT_H_INCLUDED
#define STAT_H_INCLUDED

void enregistrerTentative(int tentative, const char* pseudo);
void calculerEcartType(const char* pseudo);
void consulterTentatives(const char* pseudo);

#endif //�STAT_H_INCLUDED
