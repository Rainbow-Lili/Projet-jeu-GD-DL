#ifndef DIFFICULTE_H_INCLUDED
#define DIFFICULTE_H_INCLUDED

void choisirNiveau(int* max, int* tentativesMax);

#endif // DIFFICULTE_H_INCLUDED
