/**********************************************************************
*Auteur         : GANDA & DAKEY
*Parcours       : EPL G�nie Logiciel S3
*Ann�es         : 2024-2025
*Description    : Programme de jeu de devinette
***********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>
#include "random.h"
#include "jeu.h"
#include "difficulte.h"
#include "pseudo.h"
#include "stat.h"

int main() {
    setlocale(LC_CTYPE, "");
    printf("\n\n\t\t\t\t\t=============================\n");
    printf("\t\t\t\t\t|  BIENVENUE SUR NOTRE JEU  |\n");
    printf("\t\t\t\t\t|        DE DEVINETTE       |\n");
    printf("\t\t\t\t\t=============================\n\n");

    char pseudo[100];
    char motDePasse[100];

    while (1) {
        printf("\n-----------------------------------------------\n");
        printf("Entrez votre pseudo : ");
        // Demande du pseudo
        scanf("%99s", pseudo);

        if (verifierPseudoEtMotDePasse(pseudo, motDePasse) == 0) {
            // Demande du mot de passe pour un nouveau pseudo
            printf("Entrez votre mot de passe : ");
            scanf("%99s", motDePasse);

            if (enregistrerPseudo(pseudo, motDePasse)) {
                printf("\nInscription r�ussie pour %s.\n", pseudo);
                break;
            } else {
                printf("\nLe pseudo existe d�j�. Veuillez en entrer un autre.\n");
            }
        } else {
            printf("\nConnexion r�ussie !\n");
            break;
        }
        printf("-----------------------------------------------\n");
    }

    srand(time(NULL)); // Initialisation de la graine al�atoire

    int max = 0, tentativesMax = 0;
    char decision[4];

    do {
        choisirNiveau(&max, &tentativesMax); // Choix du niveau de difficult�
        jeuDeDevinette(max, tentativesMax); // Lancer le jeu de devinette

        while (1) {
            //Demande si l'utilisateur souhaite rejouer
            printf("\nVoulez-vous rejouer (O / N) : ");
            scanf("%3s", decision);

            if (strcmp(decision, "N") == 0 || strcmp(decision, "n") == 0) {
                printf("\nMerci d'avoir jou� !\n");
                break;
            } else if (strcmp(decision, "O") == 0 || strcmp(decision, "o") == 0) {
                break;
            } else {
                printf("\nChoix invalide. Veuillez entrer 'O' pour oui ou 'N' pour non.\n");
            }
        }
    } while (strcmp(decision, "O") == 0 || strcmp(decision, "o") == 0);

    printf("\nRetour au menu principal.\n");
    return 0;
}
