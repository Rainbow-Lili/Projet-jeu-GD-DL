#ifndef STAT_H_INCLUDED
#define STAT_H_INCLUDED

void enregistrerTentative(int tentative);
void calculerEcartType();
void consulterTentatives();

#endif //�STAT_H_INCLUDED
